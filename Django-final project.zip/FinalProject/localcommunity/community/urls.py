from django.urls import path
from . import views

urlpatterns =[
    path('',views.index,name='home'),
    path('services/',views.service,name='service'),
    path('queries/',views.queries,name='queries'),
    path('sdetail/<int:pk>/',views.service_detail,name='service_detail'),
    path('qdetail/<int:pk>/',views.queries_detail,name='queries_detail'),
    path('snew/new/',views.service_new,name='service_new'),
    path('qnew/new/',views.queries_new,name='queries_new'),
    path('signup',views.signup,name='signup'),
    path('signin',views.signin,name='signin'),
    path('signout',views.signout,name='signout'),
]