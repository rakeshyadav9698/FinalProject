from django import forms
from .models import Services,Queries

class Servicesform(forms.ModelForm):
    class Meta:
        model = Services
        fields = ('service_name','service_provider_name','price','contact_number')

class Queriesform(forms.ModelForm):
    class Meta:
        model = Queries
        fields = ('question_Category','question_Details')