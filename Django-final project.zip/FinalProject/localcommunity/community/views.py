from django.shortcuts import render,HttpResponse,get_object_or_404,redirect
from .models import Services,Queries
from .forms import Servicesform,Queriesform
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login,logout

# Create your views here.
def index(request):
    return render(request, 'index.html')

@login_required
def service(request):
    # return HttpResponse("This will be my services page!!")
    services = Services.objects.all().values()
    local_service = {'services': services}
    return render(request,'service.html',local_service)

@login_required
def queries(request):
    #return HttpResponse("This will be my queries page!!")
    query = Queries.objects.all().order_by('question_Category')
    local_queries = {'query':query}
    return render(request,'queries.html',local_queries)

def service_detail(request,pk):
    sdetail = get_object_or_404(Services,pk=pk)
    return render(request,'service_detail.html',{'sdetail':sdetail})

def queries_detail(request,pk):
    qdetail = get_object_or_404(Queries,pk=pk)
    return render(request,'queries_detail.html',{'qdetail':qdetail})

def service_new(request):
    sform = Servicesform()
    return render(request,'service_new.html',{'service_form':sform})

def queries_new(request):
    qform = Queriesform()
    return render(request,'queries_new.html',{'queries_form':qform})

def signup(request):
    if request.method == 'POST':
        #username = request.POST.get('username')
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        myuser =  User.objects.create_user(username,email,pass1)
        myuser.first_name = fname
        myuser.last_name = lname

        myuser.save()

        messages.success(request, "Your Account has been successfully created..")

        return redirect('signin')

    return render(request,'registration/signup.html')

def signin(request):
    if request.method == "POST":
        username = request.POST['username']
        pass1 = request.POST['pass1']

        user = authenticate(username=username,password=pass1)

        if user is not None:
            login(request,user)
            fname = user.first_name
            return render(request, "index.html", {'fname':fname})
        else:
            messages.error(request,"Invalid Credentials!!")
            return redirect('home')

    return render(request,'registration/signin.html')

def signout(request):
    logout(request)
    messages.success(request, "Logged Out Successfully")
    return redirect('home')
