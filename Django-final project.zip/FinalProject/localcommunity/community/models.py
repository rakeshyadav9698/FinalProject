from django.db import models
from django.utils import timezone
# Create your models here.
class Services(models.Model):
    service_name = models.CharField(max_length=200)
    service_provider_name = models.CharField(max_length=50)
    price = models.CharField(max_length=50)
    contact_number = models.CharField(max_length=20)

    def __str__(self):
        return self.service_name

class Queries(models.Model):
    question_Category = models.CharField(max_length=50)
    question_Details = models.CharField(max_length=250)

    def __str__(self):
        return self.question_Category